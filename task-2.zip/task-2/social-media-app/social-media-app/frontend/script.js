// frontend/script.js

// Registration
async function registerUser(username, email, password) {
    try {
        const response = await fetch('http://localhost:5001/api/users/register', { // Corrected port
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password }),
        });
        const data = await response.json();
        if (response.ok) {
            localStorage.setItem('token', data.token);
            console.log('Registration successful!');
            getProfile();
        } else {
            console.error(data.message);
        }
    } catch (error) {
        console.error('Error during registration:', error);
    }
}

// Login
async function loginUser(email, password) {
    try {
        const response = await fetch('http://localhost:5001/api/users/login', { // Corrected port
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
        });
        const data = await response.json();
        if (response.ok) {
            localStorage.setItem('token', data.token);
            console.log('Login successful!');
            getProfile();
        } else {
            console.error(data.message);
        }
    } catch (error) {
        console.error('Error during login:', error);
    }
}

// Get Profile
async function getProfile() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:5001/api/users/profile', { // Corrected port
            headers: { 'x-auth-token': token },
        });
        if (response.ok) {
            const user = await response.json();
            console.log('User profile:', user);
            displayProfile(user);
        } else {
            console.error('Failed to fetch profile');
        }
    } catch (error) {
        console.error('Error fetching profile:', error);
    }
}

function displayProfile(user) {
    const profileDiv = document.getElementById('profile');
    if (profileDiv) {
        profileDiv.innerHTML = `
            <h2>${user.username}</h2>
            <p>Email: ${user.email}</p>
            <p>Followers: ${user.followers ? user.followers.length : 0}</p>
            <p>Following: ${user.following ? user.following.length : 0}</p>
        `;
    }
}

// Create a post
async function createPost(text) {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:5001/api/posts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-auth-token': token,
            },
            body: JSON.stringify({ text }),
        });
        if (response.ok) {
            console.log('Post created successfully');
            getPosts();
        } else {
            console.error('Failed to create post');
            const errorData = await response.json();
            console.error('Backend Error:', errorData);
        }
    } catch (error) {
        console.error('Error creating post:', error);
    }
}

// Get all posts
async function getPosts() {
    try {
        const response = await fetch('http://localhost:5001/api/posts'); // Corrected port
        if (response.ok) {
            const posts = await response.json();
            displayPosts(posts);
        } else {
            console.error('Failed to get posts');
        }
    } catch (error) {
        console.error('Error getting posts:', error);
    }
}

function displayPosts(posts) {
    const postsDiv = document.getElementById('posts');
    if (postsDiv) {
        postsDiv.innerHTML = '';
        posts.forEach((post) => {
            const postDiv = document.createElement('div');
            postDiv.innerHTML = `
                <p><strong>${post.user.username}:</strong> ${post.text}</p>
                <button onclick="likePost('${post._id}')">Like</button>
                <button onclick="addComment('${post._id}')">Comment</button>
                <div id="comments-${post._id}"></div>
            `;
            postsDiv.appendChild(postDiv);
        });
    }
}

// Like a post
async function likePost(postId) {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`http://localhost:5001/api/posts/like/${postId}`, { // Corrected port
            method: 'POST',
            headers: { 'x-auth-token': token },
        });
        if (response.ok) {
            console.log('Post liked successfully');
            getPosts();
        } else {
            console.error('Failed to like post');
        }
    } catch (error) {
        console.error('Error liking post:', error);
    }
}

// Add a comment
async function addComment(postId) {
    const commentText = prompt('Enter your comment:');
    if (commentText) {
        try {
            const token = localStorage.getItem('token');
            const response = await fetch(`http://localhost:5001/api/posts/comment/${postId}`, { // Corrected port
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-auth-token': token,
                },
                body: JSON.stringify({ text: commentText }),
            });
            if (response.ok) {
                console.log('Comment added successfully');
                getPosts();
            } else {
                console.error('Failed to add comment');
            }
        } catch (error) {
            console.error('Error adding comment:', error);
        }
    }
}

// Follow a user
async function followUser(userId) {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`http://localhost:5001/api/users/follow/${userId}`, { // Corrected port
            method: 'POST',
            headers: { 'x-auth-token': token },
        });
        if (response.ok) {
            console.log('User followed successfully');
            getProfile();
        } else {
            console.error('Failed to follow user');
        }
    } catch (error) {
        console.error('Error following user:', error);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const registrationForm = document.getElementById('registration-form');
    const loginForm = document.getElementById('login-form');
    const postForm = document.getElementById('post-form');

    if (registrationForm) {
        registrationForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const username = document.getElementById('register-username').value;
            const email = document.getElementById('register-email').value;
            const password = document.getElementById('register-password').value;
            registerUser(username, email, password);
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            loginUser(email, password);
        });
    }

    if (postForm) {
        postForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const text = document.getElementById('post-input').value;
            createPost(text);
        });
    }

    if (localStorage.getItem('token')) {
        getProfile();
        getPosts();
    } else {
        getPosts();
    }
});